// kev value 数据
export interface IKVData {
	code: string;
	desc: string;
}
